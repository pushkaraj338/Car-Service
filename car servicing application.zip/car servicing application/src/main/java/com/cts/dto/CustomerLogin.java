package com.cts.dto;

public class CustomerLogin extends Login {

}
