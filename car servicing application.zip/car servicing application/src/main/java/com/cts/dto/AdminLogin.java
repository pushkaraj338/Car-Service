package com.cts.dto;

public class AdminLogin extends Registration {

	public AdminLogin() {
		super();
	}

	public AdminLogin(String firstName, String lastName, String phone, String email, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.email = email;
		this.password = password;
	}

}
