package com.cts.dto;

public class CustomerRequest {
	protected String name;
	protected String vehicleType;
	protected String email;
	protected String phone;
	protected String service;
	protected String date;
	protected String time;
	protected String defect;
	public CustomerRequest(String name, String vehicleType, String email, String phone, String service, String date,
			String time, String defect) {
		super();
		this.name = name;
		this.vehicleType = vehicleType;
		this.email = email;
		this.phone = phone;
		this.service = service;
		this.date = date;
		this.time = time;
		this.defect = defect;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDefect() {
		return defect;
	}
	public void setDefect(String defect) {
		this.defect = defect;
	}
	
	

}
