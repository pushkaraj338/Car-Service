package com.cts.dto;


public class CustomerRegistration extends Registration {
	
	public CustomerRegistration() {
		super();
	}

	public CustomerRegistration(String firstname, String lastname, String phone, String email, String psw) {
		// TODO Auto-generated constructor stub
		super();
		this.firstName = firstname;
		this.lastName = lastname;
		this.phone = phone;
		this.email = email;
		this.password = psw;
	}
	
	public CustomerRegistration(int id,String firstname, String lastname, String phone, String email, String psw) {
		// TODO Auto-generated constructor stub
		super();
		this.id=id;
		this.firstName = firstname;
		this.lastName = lastname;
		this.phone = phone;
		this.email = email;
		this.password = psw;
	}

	
}
