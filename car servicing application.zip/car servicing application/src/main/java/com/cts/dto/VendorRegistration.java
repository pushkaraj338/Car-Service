package com.cts.dto;

public class VendorRegistration extends Registration {
	
	
	public VendorRegistration() {
		super();
	}

	public VendorRegistration(String firstname, String lastname, String phone, String email, String psw) {
		// TODO Auto-generated constructor stub
		super();
		this.firstName = firstname;
		this.lastName = lastname;
		this.phone = phone;
		this.email = email;
		this.password = psw;
	}
	 public VendorRegistration(int id,String firstname,String lastname,String phone,String email) {
		 super();
		 this.id=id;
		 this.firstName=firstname;
		 this.lastName=lastname;
		 this.phone=phone;
		 this.email=email;
		 //this.password=psw;
	 }

}
