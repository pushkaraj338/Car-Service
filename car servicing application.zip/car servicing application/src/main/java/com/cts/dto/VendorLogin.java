package com.cts.dto;

public class VendorLogin extends Login{

}
