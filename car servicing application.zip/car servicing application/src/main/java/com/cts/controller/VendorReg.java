package com.cts.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.VendorRegDao; 
import com.cts.dto.VendorRegistration;


/**
 * Servlet implementation class VendorReg
 */
@WebServlet("/VendorReg")
public class VendorReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VendorReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String firstname = request.getParameter("First Name");
		String lastname = request.getParameter("Last Name");
		String email = request.getParameter("Email");
		String phone = request.getParameter("Contact Number");
		String psw=request.getParameter("Password");
		
		VendorRegistration vendor = new VendorRegistration(firstname,lastname,phone,email,psw);

		
		VendorRegDao rDao = new VendorRegDao();
		 
		//String result;
		int result;
		
			
				try {
					result = rDao.insert(vendor);
					if(result==1) {
						response.sendRedirect("succesfull.jsp");

					}
					else{
						response.sendRedirect("sorry.jsp");

					}
					//response.getWriter().print(result);

				} catch (ClassNotFoundException | SQLException |IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		doGet(request, response);
	}

}
