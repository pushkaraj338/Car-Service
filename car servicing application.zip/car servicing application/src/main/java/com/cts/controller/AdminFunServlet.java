package com.cts.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.AdminFunctionDao;
import com.cts.dto.VendorRegistration;

/**
 * Servlet implementation class AdminFunServlet
 */
@WebServlet("/")
public class AdminFunServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AdminFunctionDao fun;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() {
		fun = new AdminFunctionDao();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getServletPath();
		switch (action) {
		case "/remove":
			removeVendor(request, response);
			break;
		case "/reject":
			rejectVendor(request, response);
			break;
		case"/approve":
			approveVendor(request,response);
			break;
		default:
			listVendor(request,response);
			break;

		}
		response.getWriter().append("Served at: ").append(request.getContextPath());

	}

	private void removeVendor(HttpServletRequest request, HttpServletResponse response) throws IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		try {
			AdminFunctionDao.rejectVendor(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect("list");
	}
	
	private void rejectVendor(HttpServletRequest request, HttpServletResponse response) throws IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		try {
			AdminFunctionDao.removeVendor(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect("list");
	}

	private void listVendor(HttpServletRequest request, HttpServletResponse response) {
			
			try {
				List<VendorRegistration> listVendor= AdminFunctionDao.selectAllVendors();
		            request.setAttribute("listVendor", listVendor);
				    RequestDispatcher dispatcher=request.getRequestDispatcher("vendor-list.jsp");
				    dispatcher.forward(request, response);
			}
			catch(Exception e) {
				e.printStackTrace();
				
			}
		}
	private void approveVendor(HttpServletRequest request, HttpServletResponse response) throws IOException {
		try {
			int id=Integer.parseInt(request.getParameter("id"));
			AdminFunctionDao.approveVendor(id);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect("list");
	}

} 
