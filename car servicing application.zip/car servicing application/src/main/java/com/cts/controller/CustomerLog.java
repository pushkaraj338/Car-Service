package com.cts.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.AdminLogDao;
import com.cts.dao.CustomerLogDao;
import com.cts.dto.AdminBean;
import com.cts.dto.CustomerLogin;

/**
 * Servlet implementation class CustomerLog
 */
@WebServlet("/Customer")
public class CustomerLog extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerLog() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String email=request.getParameter("Email");
		String password=request.getParameter("Password");
		
		CustomerLogin custlog=new CustomerLogin();
		custlog.setEmail(email);
		custlog.setPassword(password);
		
		CustomerLogDao log=new CustomerLogDao();
		
		try {
			if(log.validate(custlog)) {
				response.sendRedirect("customer_dashboard.jsp");
			}
			else {
				response.sendRedirect("CustomerLoginReg.jsp");
			}
		} catch (ClassNotFoundException | SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		doGet(request, response);
	}

}
