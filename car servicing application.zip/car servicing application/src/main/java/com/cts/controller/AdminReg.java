package com.cts.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.AdminRegDao;
import com.cts.dto.AdminLogin;


/**
 * Servlet implementation class AdminReg
 */
@WebServlet("/AdminReg")
public class AdminReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String firstname = request.getParameter("First Name");
		String lastname = request.getParameter("Last Name");
		String email = request.getParameter("Email");
		String phone = request.getParameter("Contact Number");
		String psw=request.getParameter("Password");
		
		AdminLogin admin = new AdminLogin(firstname, lastname, phone,email, psw);

		
		AdminRegDao rDao = new AdminRegDao();
		
		//String result;
		int result;
		
			
				try {
					result = rDao.insert(admin);
					if(result==1) {
						response.sendRedirect("cust_happy.jsp");
					}
					else {
						response.sendRedirect("sorry.jsp");
					}
					//response.getWriter().print(result);

				} catch (ClassNotFoundException | SQLException |IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			
		
		
		
		doGet(request, response);
	}

}
