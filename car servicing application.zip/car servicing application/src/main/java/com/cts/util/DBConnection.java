package com.cts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	 public static Connection getConnection() throws SQLException, ClassNotFoundException
     {
    
		    String dbUname= "root";
			String dbPassword = "Shubham@1999";
			String dbDriver = "com.mysql.cj.jdbc.Driver";
			String dbUrl = "jdbc:mysql://localhost:3306/userdb";
			
     Class.forName(dbDriver);
     Connection conn=DriverManager.getConnection(dbUrl,dbUname,dbPassword);
     return conn;
     }

}
