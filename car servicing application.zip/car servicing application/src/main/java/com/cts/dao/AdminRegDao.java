package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cts.dto.AdminLogin;
import com.cts.util.DBConnection;



public class AdminRegDao {
	/*private String dbUrl = "jdbc:mysql://localhost:3306/userdb";
	private String dbUname = "root";
	private String dbPassword = "Shubham@1999";
	private String dbDriver = "com.mysql.cj.jdbc.Driver";
	
	public void loadDriver(String dbDriver)
	{
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Connection getConnection()
	{
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbUrl, dbUname, dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}*/
	
	
	public int insert(AdminLogin admin) throws ClassNotFoundException, SQLException
	{
		/*loadDriver(dbDriver);
		Connection con=getConnection();*/
		
		Connection con=DBConnection.getConnection();
		//String result = "Data entered successfully";
		int result=0;
		String sql = "insert into admin values(?,?,?,?,?)";
		
		PreparedStatement ps;
		try {
		ps = con.prepareStatement(sql);
		ps.setString(1, admin.getFirstName());
		ps.setString(2, admin.getLastName());
		ps.setString(3, admin.getPhone());
		ps.setString(4, admin.getEmail());
		ps.setString(5, admin.getPassword());

		result=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//result = "Data not entered";
		}
		return result;
	}
	
	


}
