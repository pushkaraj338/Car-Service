package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cts.dto.AdminLogin;
import com.cts.dto.VendorRegistration;
import com.cts.util.DBConnection;

public class VendorRegDao {
	public int insert(VendorRegistration vendor) throws ClassNotFoundException, SQLException
	{
		/*loadDriver(dbDriver);
		Connection con=getConnection();*/
		
		Connection con=DBConnection.getConnection();
		//String result = "Data entered successfully";
		String sql = "insert into vendor"+"(first_name,last_name,phone,email,password)"+" values(?,?,?,?,?)";
		int result=0;
		PreparedStatement ps;
		try {
		ps = con.prepareStatement(sql);
		ps.setString(1, vendor.getFirstName());
		ps.setString(2, vendor.getLastName());
		ps.setString(3, vendor.getPhone());
		ps.setString(4, vendor.getEmail());
		ps.setString(5, vendor.getPassword());

		 result=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//result = "Data not entered";
		}
		return result;
	}
	

	

}
