package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cts.dto.AdminLogin;
import com.cts.dto.CustomerRegistration;
import com.cts.util.DBConnection;

public class CustomerRegDao {

	public int  insert(CustomerRegistration cust) throws ClassNotFoundException, SQLException {

		Connection con = DBConnection.getConnection();
		//String result = "Data entered successfully";
		String sql = "insert into cust"+"(first_name,last_name,phone,email,password)"+" values(?,?,?,?,?)";
		int result=0;

		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, cust.getFirstName());
			ps.setString(2, cust.getLastName());
			ps.setString(3, cust.getPhone());
			ps.setString(4, cust.getEmail());
			ps.setString(5, cust.getPassword());

			result=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//result = "Data not entered";
		}
		return result;
	}

}
