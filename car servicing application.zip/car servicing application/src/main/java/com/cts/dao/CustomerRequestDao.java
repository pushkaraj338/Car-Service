package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cts.dto.AdminLogin;
import com.cts.dto.CustomerRequest;
import com.cts.util.DBConnection;

public class CustomerRequestDao {
	
	
	
	public int insert(CustomerRequest request) throws ClassNotFoundException, SQLException
	{
		/*loadDriver(dbDriver);
		Connection con=getConnection();*/
		
		Connection con=DBConnection.getConnection();
		//String result = "Data entered successfully";
		String sql = "insert into cust_request values(?,?,?,?,?,?,?,?)";
		
		int result=0;
		
		PreparedStatement ps;
		try {
		ps = con.prepareStatement(sql);
		ps.setString(1, request.getName());
		ps.setString(2, request.getVehicleType());
		ps.setString(3, request.getEmail());
		ps.setString(4, request.getPhone());
		ps.setString(5, request.getService());
		ps.setString(6, request.getDate());
		ps.setString(7, request.getTime());
		ps.setString(8, request.getDefect());



		result=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//result = "Data not entered";
		}
		return result;
	}

}
