package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.dto.VendorRegistration;
import com.cts.util.DBConnection;

public class AdminFunctionDao {
	
	private static final String SELECT_ALL_VENDOR="select id,first_name,last_name,phone,email from vendor";
	private static final String VIEW_ALL_VENDOR="select id,first_name,last_name,phone,email from PRE_vendor";

	private static final String DELETE_VENDOR="delete from vendor where id=?";
	private static final String APPROVE_VENDOR="insert into per_vendor(id,first_name,last_name,phone,email,password) "
			+ "select id,first_name,last_name,phone,email,password from vendor where id=?";
	
	public AdminFunctionDao() {
		super();
	}
	
	
	
	//select all vendor
	public static    List<VendorRegistration> selectAllVendors(){
		List <VendorRegistration> vendors=new ArrayList<>();
		try {
			
			Connection con=DBConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(SELECT_ALL_VENDOR);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				int id=rs.getInt("id");
				String firstName=rs.getString("first_name");
				String lastName=rs.getString("last_name");
				String phone=rs.getString("phone");
				String email=rs.getString("email");
				//String password=rs.getString("password");
				
				vendors.add( new VendorRegistration(id,firstName,lastName,phone,email));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return vendors;
	}
	//veiw all vendor
	
	/*public static    List<VendorRegistration> viewAllVendors(){
		List <VendorRegistration> vendors=new ArrayList<>();
		try {
			
			Connection con=DBConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(VIEW_ALL_VENDOR);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				int id=rs.getInt("id");
				String firstName=rs.getString("first_name");
				String lastName=rs.getString("last_name");
				String phone=rs.getString("phone");
				String email=rs.getString("email");
				//String password=rs.getString("password");
				
				vendors.add( new VendorRegistration(id,firstName,lastName,phone,email));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return vendors;
	}*/
	
	//delete the vendor
	
	public static   boolean rejectVendor(int id) throws SQLException{
		boolean rowDeleted = false;
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(DELETE_VENDOR);
			ps.setInt(1, id);
			rowDeleted=ps.executeUpdate()>0;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return rowDeleted;
		
	}
	public static   boolean removeVendor(int id) throws SQLException{
		boolean rowDeleted = false;
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(DELETE_VENDOR);
			ps.setInt(1, id);
			rowDeleted=ps.executeUpdate()>0;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return rowDeleted;
		
	}
	public static void approveVendor(int id)throws SQLException{
		try {
			Connection con=DBConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(APPROVE_VENDOR);
			ps.setInt(1, id);
			ps.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("Data is already approved");
			//e.printStackTrace();
		}
	}
	

}
